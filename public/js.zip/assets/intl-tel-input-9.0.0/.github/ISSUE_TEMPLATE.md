IMPORTANT: please note that the autoFormat feature (format-as-you-type) was removed in v8.0.0 - read more here: https://github.com/jackocnr/intl-tel-input/issues/346. Please do not open any new issues about this topic.

### Steps to reproduce
1.  
2.  
3.  

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what actually happens

### Initialisation options
List any options you're using e.g. utilsScript or preferredCountries
