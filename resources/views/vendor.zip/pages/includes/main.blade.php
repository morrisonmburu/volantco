@include("pages.includes.head")
@include("pages.includes.nav")

	@yield("content")

@include("pages.includes.footer")